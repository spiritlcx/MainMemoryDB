g++ -std=c++11 -g -O3 -Wall -fPIC -rdynamic tree_expression.cpp -shared -o tree_expression.so
