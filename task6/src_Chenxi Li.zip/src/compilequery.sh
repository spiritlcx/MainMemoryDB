g++ -std=c++11 -g -O3 -Wall -fPIC -rdynamic query_expression.cpp -shared -o query_expression.so
